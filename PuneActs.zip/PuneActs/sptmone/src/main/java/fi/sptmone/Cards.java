package fi.sptmone;

public class Cards {

}
