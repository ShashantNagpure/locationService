package fi.microusersservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MicrousersserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
